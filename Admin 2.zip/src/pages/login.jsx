import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { request } from "../utils/apiService";
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Login() {
  const router = useNavigate();
  const [formData, setFormData] = useState({
    cnic: "",
    password: "",
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate input
    if (!formData.cnic || !formData.password) {
      toast.error("Please enter both CNIC and Password");
      return;
    }

    setIsLoading(true);
    try {
      const res = await request("users/login", "POST", formData);
      
      if (res.status === 200) {
        localStorage.setItem("token", res.data.token);
        toast.success("Login Successful!");
        
        // Small delay to show success message before routing
        setTimeout(() => {
          router("/rarefinds");
        }, 1500);
      }
    } catch (error) {
      // Handle different types of login errors
      if (error.response) {
        switch (error.response.status) {
          case 401:
            toast.error("Invalid CNIC or Password");
            break;
          case 404:
            toast.error("User not found");
            break;
          default:
            toast.error("Login failed. Please try again.");
        }
      } else {
        toast.error("Network error. Please check your connection.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    token && router("/rarefinds");
  }, []);

  return (
    <div className="flex justify-center items-center h-screen w-screen bg-gray-100">
      <div className="h-fit w-[400px] rounded-lg max-sm:w-full p-5 shadow-2xl bg-white">
        {/* Welcome Admin Text */}
        <div className="absolute top-10 left-1/2 transform -translate-x-1/2 text-4xl font-extrabold text-gray-800 
                        text-shadow-xl">
          Welcome Admin
        </div>

        {/* Project Name */}
        <div className="absolute top-5 left-5 text-5xl font-extrabold text-black 
                        text-shadow-xl">
          RAREFINDS
        </div>

        <h1 className="text-3xl text-center font-bold mb-10 text-gray-800">Login</h1>
        
        <form onSubmit={handleSubmit} className="mt-10">
          <div className="flex flex-col gap-2">
            <label htmlFor="cnic" className="text-gray-700">CNIC</label>
            <input
              id="cnic"
              type="text"
              value={formData.cnic}
              onChange={({target}) => {
                setFormData(pre=>({...pre,cnic:target.value}));
              }}
              className="border p-2 rounded-3xl focus:outline-none focus:ring-2 focus:ring-black"
              placeholder="Enter your CNIC"
            />
          </div>
          
          <div className="flex flex-col gap-2 mt-4">
            <label htmlFor="password" className="text-gray-700">Password</label>
            <input
              id="password"
              type="password"
              value={formData.password}
              onChange={(e) => {
                e.preventDefault();
                setFormData({ ...formData, password: e.target.value });
              }}
              className="border p-2 rounded-3xl focus:outline-none focus:ring-2 focus:ring-black"
              placeholder="Enter your password"
            />
          </div>
          
          <button
            type="submit"
            disabled={isLoading}
            className={`w-full text-white p-3 rounded-3xl mt-5 transition-colors duration-300 ${
              isLoading 
                ? 'bg-gray-400 cursor-not-allowed' 
                : 'bg-black hover:bg-white hover:text-black border-2 border-black'
            }`}
          >
            {isLoading ? 'Logging in...' : 'Submit'}
          </button>
        </form>
      </div>
      
      {/* Toast Notification Container */}
      <ToastContainer 
        position="top-right"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </div>
  );
}

export default Login;
