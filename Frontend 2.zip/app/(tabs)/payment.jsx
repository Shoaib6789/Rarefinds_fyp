import React, { useState, useCallback, useContext } from 'react';
import { 
  View, 
  Text, 
  ActivityIndicator, 
  ScrollView, 
  Alert, 
  Dimensions,
  StyleSheet,
  Platform 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { request } from '../../lib/apiService';
import CardMini from '@/components/CardMini';
import { 
  depositPayment, 
  connectWallet, 
  releasePayment, 
  raiseDispute 
} from '../../services/ethereumService';
import { MyUserContext } from "../../components/userContext";

const Payment = () => {
  const [paymentStatus, setPaymentStatus] = useState(false);
  const [disputeStatus, setDisputeStatus] = useState(true);
  const [releaseStatus, setReleaseStatus] = useState(true);
  const [wonItems, setWonItems] = useState([]);
  const [soldItems, setSoldItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const screenWidth = Dimensions.get('window').width;
  const { user } = useContext(MyUserContext);

  const handlePaymentSuccess = () => {
    setPaymentStatus(true);
    setDisputeStatus(false);
    setReleaseStatus(false);
  };

  const getWonItems = async () => {
    try {
      const res = await request("items/wonItems", "GET");
      setWonItems(res.data.items);
    } catch (error) {
      console.log(error);
    }
  };

  const getSoldItems = async () => {
    try {
      const res = await request("items/soldItems", "GET");
      setSoldItems(res.data.items);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  const handlePayment = async (item) => {
    try {
      await connectWallet();
      const paymentSuccess = await depositPayment(item.currentHighestBid);
      if (paymentSuccess) {
        Alert.alert('Success', 'Payment has been successfully deposited!');
        handlePaymentSuccess();
      }
    } catch (error) {
      console.error('Payment failed:', error);
      Alert.alert('Error', `Payment failed: ${error.message}`);
    }
  };

  const handleReleasePayment = async () => {
    try {
      await connectWallet();
      const releaseSuccess = await releasePayment();
      if (releaseSuccess) {
        Alert.alert('Success', 'Payment released successfully!');
        setReleaseStatus(true);
        setPaymentStatus(true);
        setDisputeStatus(true);
      }
    } catch (error) {
      console.error('Release payment failed:', error);
      Alert.alert('Error', `Release payment failed: ${error.message}`);
    }
  };

  const handleRaiseDispute = async () => {
    try {
      await connectWallet();
      const disputeSuccess = await raiseDispute();
      if (disputeSuccess) {
        Alert.alert('Success', 'Dispute raised successfully!');
        setReleaseStatus(true);
        setPaymentStatus(true);
        setDisputeStatus(true);
      }
    } catch (error) {
      console.error('Raise dispute failed:', error);
      Alert.alert('Error', `Raise dispute failed: ${error.message}`);
    }
  };

  useFocusEffect(
    useCallback(() => {
      setLoading(true);
      getWonItems();
      getSoldItems();
    }, [])
  );
 const renderItemSection = (title, items, emptyMessage) => {
    return (
      <View style={styles.sectionContainer}>
        <Text style={styles.sectionTitle}>{title}</Text>
        {loading ? (
          <ActivityIndicator 
            size="large" 
            color="#4a90e2" 
            style={styles.loadingIndicator}
          />
        ) : (
          <View style={styles.itemGridContainer}>
            {items.length ? (
              items.map((item, index) => (
                <View key={index} style={styles.itemCardWrapper}>
                  <CardMini
                    paymentStatus={paymentStatus}
                    disputeStatus={disputeStatus}
                    releaseStatus={releaseStatus}
                    setPaymentStatus={setPaymentStatus}
                    setDisputeStatus={setDisputeStatus}
                    setReleaseStatus={setReleaseStatus}
                    onPaymentSuccess={handlePaymentSuccess}
                    isPayment={true}
                    paymentText={"Make Payment"}
                    raiseDisputeText={"Raise Dispute"}
                    releasePaymentText={"Release Payment"}
                    id={item.itemId._id}
                    img={item.itemId.images[0]}
                    title={item.itemId.title}
                    bid={item.currentHighestBid}
                    onPressPayment={() => handlePayment(item)}
                    onRaiseDispute={handleRaiseDispute}
                    onReleasePayment={handleReleasePayment}
                  />
                </View>
              ))
            ) : (
              <Text style={styles.emptyStateText}>{emptyMessage}</Text>
            )}
          </View>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        contentContainerStyle={styles.scrollViewContent}
      >
        <View style={styles.contentContainer}>
          {renderItemSection(
            "Won Bids", 
            wonItems, 
            "You haven't won a bid yet"
          )}
          
          {renderItemSection(
            "Sold Items", 
            soldItems, 
            "You haven't sold an item yet"
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Platform.OS === 'web' ? '#f7f7f7' : '#fff',
  },
  scrollViewContent: {
    flexGrow: 1,
    width: '100%',
    paddingHorizontal: Platform.OS === 'web' ? 20 : 0,
  },
  contentContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionContainer: {
    width: '100%',
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },
  loadingIndicator: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemGridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  itemCardWrapper: {
    width: Platform.OS === 'web' ? '33.33%' : '100%',
    padding: 16,
  },
  emptyStateText: {
    textAlign: 'center', 
    fontSize: 20, 
    color: '#666',
    marginTop: 20,
  },
});

export default Payment;