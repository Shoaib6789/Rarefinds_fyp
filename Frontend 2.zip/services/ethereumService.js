
import { ethers } from 'ethers';

const escrowABI = [
    "function deposit() external payable",
    "function releasePayment() external",
    "function raiseDispute() external",
    "function resolveDispute(bool decision) external",
];

const escrowAddress = "0xBC3C8EC7e5873D5D1B35c0e0E9a13732Be96C10C";


let provider;
let signer;

const connectWallet = async () => {
    if (typeof window !== 'undefined' && window.ethereum) {
        try {
            await window.ethereum.request({ method: 'eth_requestAccounts' });
            provider = new ethers.BrowserProvider(window.ethereum);
            signer = await provider.getSigner();
            console.log("Wallet connected:", await signer.getAddress());
            return signer;
        } catch (error) {
            console.error("User rejected wallet connection:", error);
            throw new Error("Wallet connection failed.");
        }
    } else {
        provider = readOnlyProvider;
        console.log("Using read-only provider");
        return provider;
    }
};

const ensureWalletConnected = async () => {
    if (!signer) {
        console.log("Wallet is not connected. Attempting to connect...");
        await connectWallet();
    }

    if (!signer) {
        throw new Error("Signer is not available. Please connect your wallet.");
    }
};

export const depositPayment = async (amountInEther) => {
    try {
        await ensureWalletConnected();
        const escrowContract = new ethers.Contract(escrowAddress, escrowABI, signer);
        const amountInWei = ethers.parseEther(amountInEther.toString());

        const tx = await escrowContract.deposit({ value: amountInEther });
        console.log("Transaction sent:", tx);

        const receipt = await tx.wait();
        console.log("Transaction mined:", receipt);

        console.log("Payment deposited successfully!");
        return true;
    } catch (error) {
        console.error("Error depositing payment:", error);
        throw new Error(error.message);
    }
};

// New functions for release and dispute
export const releasePayment = async () => {
    try {
        await ensureWalletConnected();
        const escrowContract = new ethers.Contract(escrowAddress, escrowABI, signer);

        const tx = await escrowContract.releasePayment();
        console.log("Release payment transaction sent:", tx);

        const receipt = await tx.wait();
        console.log("Release payment transaction mined:", receipt);

        return true;
    } catch (error) {
        console.error("Error releasing payment:", error);
        throw new Error(error.message);
    }
};

export const raiseDispute = async () => {
    try {
        await ensureWalletConnected();
        const escrowContract = new ethers.Contract(escrowAddress, escrowABI, signer);

        const tx = await escrowContract.raiseDispute();
        console.log("Raise dispute transaction sent:", tx);

        const receipt = await tx.wait();
        console.log("Raise dispute transaction mined:", receipt);

        return true;
    } catch (error) {
        console.error("Error raising dispute:", error);
        throw new Error(error.message);
    }
};
export { connectWallet };