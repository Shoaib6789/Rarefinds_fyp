import React, { useState } from 'react';
import { 
  TouchableOpacity, 
  View, 
  Text, 
  Modal, 
  Platform, 
  Dimensions,
  StyleSheet
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useColorScheme } from 'react-native';
import { Image } from 'react-native';
import { ThemedView } from './ThemedView';
import { ThemedText } from './ThemedText';
import { useRouter } from 'expo-router';

const CardMini = ({ 
  img, 
  title, 
  bid, 
  id, 
  isPayment, 
  paymentText, 
  raiseDisputeText,
  releasePaymentText,
  onPressPayment,
  onRaiseDispute,
  onReleasePayment,
  paymentStatus,
  disputeStatus,
  releaseStatus,
  setPaymentStatus,
  setDisputeStatus,
  setReleaseStatus,
  onPaymentSuccess
}) => {
  const [imageModalVisible, setImageModalVisible] = useState(false);
  const theme = useColorScheme();
  const router = useRouter();
  const screenWidth = Dimensions.get('window').width;

  const handlePress = () => {
    if (isPayment) {
      setImageModalVisible(true);
    } else {
      router.push({ 
        pathname: "/(product)/[product]", 
        params: { product: id } 
      });
    }
  };

  const handlePaymentPress = () => {
    try {
      if (onPressPayment) {
        onPressPayment();
      }
      setImageModalVisible(false);
    } catch (error) {
      console.error("Error during payment: ", error);
    }
  };

  const handleRaiseDispute = () => {
    try {
      if (onRaiseDispute) {
        onRaiseDispute();
      }
    } catch (error) {
      console.error("Error raising dispute: ", error);
    }
  };

  const handleReleasePayment = () => {
    try {
      if (onReleasePayment) {
        onReleasePayment();
      }
    } catch (error) {
      console.error("Error releasing payment: ", error);
    }
  };

  return (
    <>
      <Modal
        transparent
        statusBarTranslucent
        animationType="fade"
        visible={imageModalVisible}
        onRequestClose={() => setImageModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <TouchableOpacity
            style={styles.closeButton}
            onPress={() => setImageModalVisible(false)}
          >
            <Ionicons 
              name="close" 
              size={30} 
              color="white" 
            />
          </TouchableOpacity>
          
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>
              Please proceed to payment
            </Text>
            
            <TouchableOpacity
              style={[styles.modalButton, { backgroundColor: paymentStatus ? '#666' : '#000' }]}
              onPress={handlePaymentPress}
              disabled={paymentStatus}
            >
              <Text style={styles.modalButtonText}>
                {paymentText}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modalButton, { backgroundColor: disputeStatus ? '#666' : '#000', marginTop: 8 }]}
              onPress={handleRaiseDispute}
              disabled={disputeStatus} 
            >
              <Text style={styles.modalButtonText}>
                {raiseDisputeText}
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modalButton, { backgroundColor: releaseStatus ? '#666' : '#000', marginTop: 8 }]}
              onPress={handleReleasePayment}
              disabled={releaseStatus} 
            >
              <Text style={styles.modalButtonText}>
                {releasePaymentText}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Card View */}
      <View style={styles.cardContainer}>
        <ThemedView style={styles.card}>
          <TouchableOpacity 
            activeOpacity={0.8} 
            onPress={handlePress}
          >
            <View>
              <Image 
                source={{ uri: img }} 
                style={styles.cardImage} 
                resizeMode="cover" 
              />
              
              <View style={styles.cardContent}>
                <ThemedText 
                  style={styles.cardTitle}
                  numberOfLines={2}
                >
                  {title}
                </ThemedText>
                
                <View style={styles.cardFooter}>
                  <ThemedText style={styles.cardPrice}>
                    RS. {bid}/-
                  </ThemedText>
                  
                  {isPayment && (
                    <TouchableOpacity 
                      onPress={(e) => {
                        e.stopPropagation(); // Prevent parent TouchableOpacity from triggering
                        setImageModalVisible(true);
                      }}
                      style={styles.payButton}
                    >
                      <Text style={styles.payButtonText}>
                        Proceed
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            </View>
          </TouchableOpacity>
        </ThemedView>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  closeButton: {
    position: 'absolute',
    top: 20,
    right: 20,
    zIndex: 10,
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
  },
  modalButton: {
    backgroundColor: '#000',
    borderRadius: 30,
    paddingVertical: 12,
    paddingHorizontal: 20,
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
    textAlign: 'center',
  },
  cardContainer: {
    width: Platform.OS === 'web' ? '68.33%' : '100%',
    padding: 16,
  },
  card: {
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  cardImage: {
    width: '100%',
    height: 160,
  },
  cardContent: {
    padding: 16,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cardPrice: {
    color: '#4a90e2',
    fontSize: 16,
  },
  payButton: {
    backgroundColor: '#4a90e2',
    borderRadius: 20,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  payButtonText: {
    color: '#fff',
    fontSize: 14,
  },
});

export default CardMini;