import { View, Text, TouchableOpacity, Image, useColorScheme } from "react-native";
import React, { useContext } from "react";
import { ThemedView } from "./ThemedView";
import { ThemedText } from "./ThemedText";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { request } from "@/lib/apiService";
import { MyUserContext } from "./userContext";

const Card = ({ img, title, id, currentHighestBid, lotClosing }) => {
  const theme = useColorScheme();
  const { fav, setFav } = useContext(MyUserContext);

  const addFavorite = async () => {
    try {
      await request(`favorite/${id}`, "POST");
      const newFav = [...fav, id];
      setFav(newFav);
    } catch (error) {
      console.log(error);
    }
  };

  const removeFavorite = async () => {
    try {
      await request(`favorite/${id}`, "DELETE");
      const newFav = fav.filter((favId) => favId !== id);
      setFav(newFav);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={() => router.push({ pathname: `/(product)/[product]`, params: { product: id } })}
    >
      <ThemedView
        className="w-[250px] h-[320px] mr-5 m-4 rounded-3xl p-4 bg-slate-200"
        style={{
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 10 },
          shadowOpacity: 0.15,
          shadowRadius: 10,
          elevation: 5, // for Android shadow
        }}
      >
        <View className="flex flex-row justify-center bg-none ">
          <Image
            source={{ uri: img }}
            className="w-full h-[200px] rounded-xl"
            resizeMode="cover"
          />
        </View>
        <ThemedView
          className={`flex justify-end w-full ${theme === "bg-slate-200" ? "bg-gray-50" : "bg-slate-200"}`}
        >
          <View className="flex flex-row justify-between w-full mt-2">
            <ThemedText className="font-dm text-xl text-gray-800  w-2/3">{title}</ThemedText>
            {fav.includes(id) ? (
              <Ionicons size={24} name="heart" color={"#ff0000"} onPress={removeFavorite} />
            ) : (
              <Ionicons size={24} name="heart-outline" color={"#ff0000"} onPress={addFavorite} />
            )}
          </View>
          <ThemedText className="text-teal-800 text-sm mt-1">
            Current: RS. {currentHighestBid}/-
          </ThemedText>
          <ThemedText className="text-sm text-gray-600 mt-1">Closes: {lotClosing}</ThemedText>
        </ThemedView>
      </ThemedView>
    </TouchableOpacity>
  );
};

export default Card;
