const express = require('express');
const router = express.Router();
const Chat = require('../models/chatModel'); // Adjust path as needed
const ChatNote = require('../models/chatsNote'); // Adjust path as needed



router.post('/messages', async (req, res) => {
  try {
    const { 
      roomId, 
      senderId, 
      recipientId, 
      content, 
      timestamp, 
      productName,
      productId 
    } = req.body;

    // Validate required fields
    if (!roomId || !senderId || !recipientId || !content) {
      return res.status(400).json({ 
        success: false, 
        message: 'Missing required fields' 
      });
    }

    // Find or create a chat room specifically for this product and users
    let chat = await Chat.findOne({ 
      roomId,
      productName 
    });

    if (!chat) {
      // Create new chat if room doesn't exist
      chat = new Chat({
        roomId,
        productId,
        productName,
        participants: [senderId, recipientId],
        messages: []
      });
    }

    // Add new message
    chat.messages.push({
      senderId,
      recipientId,
      content,
      timestamp: timestamp || new Date()
    });

    chat.lastMessage = new Date();

    // Save the chat
    await chat.save();

    res.status(201).json({ 
      success: true, 
      message: 'Message saved successfully',
      savedMessage: chat.messages[chat.messages.length - 1]
    });

  } catch (error) {
    console.error('Error saving message:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to save message', 
      error: error.message 
    });
  }
});

// Fetching messages
router.get('/messages', async (req, res) => {
  try {
    const { productName, roomId } = req.query;

    if (!productName && !roomId) {
      return res.status(400).json({ 
        success: false, 
        message: 'Product name or room ID is required' 
      });
    }

    // Find chat by both roomId and productName
    const chat = await Chat.findOne({ 
      roomId, 
      productName 
    });

    if (!chat) {
      return res.status(404).json({ 
        success: false, 
        message: 'No messages found' 
      });
    }

    res.status(200).json({ 
      success: true, 
      messages: chat.messages 
    });

  } catch (error) {
    console.error('Error fetching messages:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to fetch messages', 
      error: error.message 
    });
  }
});


router.get('/notifications/:userId', async (req, res) => {
  const userId = req.params.userId;
  // console.log("User ID for notifications:", userId);
  
  try {
    const unreadNotifications = await ChatNote.find({
      recipientId: userId, 
      read: false  
    }).sort({ timestamp: -1 }); 
    
    return res.status(200).json({
      data: unreadNotifications,
      message: "Notifications received successfully.",
      count: unreadNotifications.length
    });
  } catch (error) {
    console.error('Error fetching notifications:', error);
    return res.status(500).json({ 
      error: error.message || 'Failed to fetch notifications',
      message: 'An error occurred while fetching notifications'
    });
  }
});


router.post('/notifications/mark-read', async (req, res) => {
  const { userId, roomId, isSeller } = req.body; // Retrieve userId and roomId from the request body
  // console.log("User ID for notifications:", userId);
  // console.log("Room ID for notifications:", roomId);

  // Validate the presence of userId and roomId
  if (!userId || !roomId) {
    return res.status(400).json({ error: 'User ID and Room ID are required' });
  }
  if (isSeller) {
    return res.status(403).json({ error: 'Sellers cannot mark messages as read' });
  }
  try {
    // Update notifications where recipientId matches userId and roomId matches the given room
    const result = await ChatNote.updateMany(
      { 
        recipientId: userId, 
        roomId: roomId, 
        read: false // Only mark unread notifications
      },
      { $set: { read: true } } // Mark notifications as read
    );

    // Respond with the result of the operation
    if (result.nModified > 0) {
      res.json({ message: 'Notifications marked as read', modifiedCount: result.nModified });
    } else {
      res.json({ message: 'No unread notifications to mark for the specified room and user' });
    }
  } catch (error) {
    console.error('Error marking notifications as read:', error);
    res.status(500).json({ error: 'Failed to mark notifications as read' });
  }
});

router.post('/notifications/mark-read-room', async (req, res) => {
  const { userId, roomId } = req.body; // Retrieve both userId and roomId from the request body
  console.log("User ID for notifications:", userId);
  console.log("Room ID for notifications:", roomId);

  // Validate input
  if (!userId || !roomId) {
    return res.status(400).json({ error: 'Both user ID and room ID are required' });
  }

  try {
    // Update only messages for the specific room and user that are unread
    const result = await ChatNote.updateMany(
      {
        recipientId: userId,
        roomId: roomId, // Match the specified room ID
        read: false,    // Only unread messages
      },
      { $set: { read: true } } // Mark messages as read
    );

    console.log(`Marked ${result.modifiedCount} messages as read for room: ${roomId}`);
    res.json({ message: 'Notifications marked as read', modifiedCount: result.modifiedCount });
  } catch (error) {
    console.error('Error marking notifications as read:', error);
    res.status(500).json({ error: 'Failed to mark notifications as read' });
  }
});


router.get('/room/:productName', async (req, res) => {
  try {
    const { productName } = req.params;
    // console.log("Fetching rooms for product:", productName);

    if (!productName) {
      return res.status(400).json({ 
        error: 'Product name is required' 
      });
    }

    // Find all rooms with the given productName
    const chatRooms = await Chat.find(
      { 
        productName: productName,
      },
      'roomId lastMessage updatedAt' // Get additional fields if needed
    ).sort({ updatedAt: -1 }); // Sort by most recent
    
    console.log(`Found ${chatRooms.length} rooms for product: ${productName}`);

    if (!chatRooms || chatRooms.length === 0) {
      return res.json([]); // Return empty array instead of 404
    }

    // Extract roomIds and any additional info you might need
    const roomData = chatRooms.map(chat => ({
      roomId: chat.roomId,
      lastMessage: chat.lastMessage,
      updatedAt: chat.updatedAt
    }));

    res.json(roomData);
  } catch (error) {
    console.error('Error fetching room IDs:', error);
    res.status(500).json({ 
      error: 'Failed to fetch chat rooms',
      details: error.message 
    });
  }
});



router.put('/message/mark-single-read', async (req, res) => {
  try {
    const { roomId, messageId, readerId, senderId } = req.body;

    // Validate input
    if (!roomId || !messageId || !readerId || !senderId) {
      return res.status(400).json({ 
        success: false, 
        message: 'Missing required fields' 
      });
    }

    // Find and update the specific message
    const updatedChat = await Chat.findOneAndUpdate(
      { 
        roomId: roomId, 
        'messages.id': messageId,
        'messages.senderId': senderId
      },
      { 
        $set: { 
          'messages.$.status': 'read',
          'messages.$.readAt': new Date() 
        } 
      },
      { new: true }
    );

    if (!updatedChat) {
      return res.status(404).json({ 
        success: false, 
        message: 'Message or chat not found' 
      });
    }

    // Emit socket event to notify other participants
    io.to(roomId).emit('messageReadConfirmation', {
      messageId,
      senderId,
      readerId,
      readAt: new Date().toISOString()
    });

    res.json({ 
      success: true, 
      message: 'Message marked as read' 
    });
  } catch (error) {
    console.error('Error marking message as read:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Internal server error' 
    });
  }
});




// router.put('/messages/mark-read', async (req, res) => {
//   try {
//     const { roomId, userId } = req.body;

//     // Validate required fields
//     if (!roomId || !userId) {
//       return res.status(400).json({
//         success: false,
//         message: 'Missing required fields: roomId and userId are required',
//       });
//     }

//     // Find the chat document
//     const chat = await Chat.findOne({ 
//       roomId, 
//       participants: userId 
//     });

//     if (!chat) {
//       return res.status(404).json({
//         success: false,
//         message: 'Chat not found',
//       });
//     }

//     // Update messages where the recipient is the user and status is 'sent'
//     const updatedChat = await Chat.findOneAndUpdate(
//       { 
//         roomId, 
//         participants: userId,
//         'messages.recipientId': userId,
//         'messages.status': 'sent'
//       },
//       { 
//         $set: { 
//           'messages.$[elem].status': 'read',
//           lastMessage: new Date()
//         } 
//       },
//       {
//         arrayFilters: [{ 
//           'elem.recipientId': userId, 
//           'elem.status': 'sent' 
//         }],
//         new: true // Return the modified document
//       }
//     );

//     if (!updatedChat) {
//       return res.status(404).json({
//         success: false,
//         message: 'No messages found to update',
//       });
//     }

//     res.status(200).json({
//       success: true,
//       message: 'Messages marked as read successfully',
//       chat: updatedChat
//     });
//   } catch (error) {
//     console.error('Error marking messages as read:', error);
//     res.status(500).json({
//       success: false,
//       message: 'Failed to mark messages as read',
//       error: error.message,
//     });
//   }
// });

module.exports = router;